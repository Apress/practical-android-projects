use Android;
my $a = Android->new();
$a->makeToast("Hello, Android!");
